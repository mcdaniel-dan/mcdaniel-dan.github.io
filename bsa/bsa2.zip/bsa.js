function onCouncilSelect() {
  var e = document.getElementsByName("councils")[0];
  var val = e.options[e.selectedIndex].value;
  //alert(val);

  var troops = document.getElementsByName("troops")[0];
  for (var i = 0; i < troops.options.length; i++) {
    if(troops.options[i].getAttribute("council") == val)
      troops.options[i].disabled = false;
    else {
      troops.options[i].disabled = true;
    }
  }
}

function onTroopSelect() {
  var e = document.getElementsByName("troops")[0];
  var val = e.options[e.selectedIndex].value;

  var selection = e.options[e.selectedIndex]

  //alert(selection.getAttribute("council"));

  var scouts = document.getElementsByName("scouts")[0];
  for (var i = 0; i < scouts.options.length; i++) {
    if(scouts.options[i].getAttribute("troop") == val
    && scouts.options[i].getAttribute("council") == selection.getAttribute("council"))
      scouts.options[i].disabled = false;
    else {
      scouts.options[i].disabled = true;
    }
  }
}

function onScoutSelect() {
  var scoutsbox = document.getElementsByName("scouts")[0];
  var options = scoutsbox.options;
  var index = scoutsbox.selectedIndex;
  var selected = options[index];
  var val = scoutsbox.options[index].value;
  //alert(val);
  var addressArray = [];

  document.getElementById("scoutname").innerHTML =
    selected.getAttribute("first_name") + " " +
    selected.getAttribute("last_name");

  addressArray.push(selected.getAttribute("street"));
  addressArray.push("\r\n");
  addressArray.push(selected.getAttribute("city"));
  addressArray.push(", ");
  addressArray.push(selected.getAttribute("state"));
  //alert(addressArray);
  document.getElementById("scoutaddress").innerHTML = addressArray.join("");

    document.getElementById("scoutphone").innerHTML =
      selected.getAttribute("phone");
    document.getElementById("scoutranks").innerHTML =
      selected.getAttribute("rank");
    document.getElementById("scoutmeritbadges").innerHTML =
      selected.getAttribute("meritbadge");
}
